import logo from "./assets/images/logo.png";
import "./App.css";
import {BrowserRouter, Route, Routes} from 'react-router-dom';


// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// каждая страница будет лежать в своей папке, откуда будет импротироваться сюда
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

import { ExamplePage } from "./pages/example/example";
import FilterPage from "./pages/filterPage/FilterPage";
import CoursePage from "./pages/course/CoursePage";

function App() {
  return (
    <div className="App">
        <BrowserRouter>
            <Routes>
                <Route path='/course' element={<CoursePage/>}/>
                <Route path='/filter' element={<FilterPage/>}/>
            </Routes>
        </BrowserRouter>

    </div>
  );
}

export default App;
